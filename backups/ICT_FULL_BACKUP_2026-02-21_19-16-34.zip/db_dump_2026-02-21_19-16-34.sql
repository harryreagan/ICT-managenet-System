-- Dallas Premiere ICT Management System Database Backup
-- Generated: 2026-02-21 19:16:34

SET FOREIGN_KEY_CHECKS=0;



-- Structure for audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('1', '1', 'DELETE', 'Deleted ticket #1 via bulk action', '2026-02-17 20:20:42');


-- Structure for backup_logs
DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_name` varchar(100) NOT NULL,
  `backup_type` varchar(50) DEFAULT NULL,
  `last_verified` datetime DEFAULT NULL,
  `status` enum('safe','at_risk','failed') DEFAULT 'safe',
  `verified_by` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for credential_vault
DROP TABLE IF EXISTS `credential_vault`;
CREATE TABLE `credential_vault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system_name` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `encrypted_password` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `responsible_staff` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for data_links
DROP TABLE IF EXISTS `data_links`;
CREATE TABLE `data_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` int(11) DEFAULT NULL,
  `cabinet_name` varchar(50) NOT NULL,
  `total_u_space` int(11) DEFAULT 42,
  `used_u_space` int(11) DEFAULT 0,
  `switch_count` int(11) DEFAULT 0,
  `connectivity_type` enum('Fiber','Ethernet','Wireless Link') DEFAULT 'Fiber',
  `status` enum('online','degraded','offline') DEFAULT 'online',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  CONSTRAINT `data_links_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for external_systems
DROP TABLE IF EXISTS `external_systems`;
CREATE TABLE `external_systems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for floor_pins
DROP TABLE IF EXISTS `floor_pins`;
CREATE TABLE `floor_pins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `data_link_id` int(11) DEFAULT NULL,
  `pos_x` int(11) DEFAULT NULL,
  `pos_y` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  KEY `asset_id` (`asset_id`),
  KEY `data_link_id` (`data_link_id`),
  CONSTRAINT `floor_pins_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `floor_pins_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `hardware_assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `floor_pins_ibfk_3` FOREIGN KEY (`data_link_id`) REFERENCES `data_links` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for floors
DROP TABLE IF EXISTS `floors`;
CREATE TABLE `floors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_number` int(11) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `map_image_path` varchar(255) DEFAULT NULL,
  `status` enum('operational','issue','offline') DEFAULT 'operational',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `floor_number` (`floor_number`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('1', '0', 'Basement', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('2', '1', 'Main Server & Lobby', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('3', '2', 'Conference Center', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('4', '3', 'Guest Rooms (F3)', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('5', '4', 'Guest Rooms (F4)', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('6', '5', 'Guest Rooms (F5)', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('7', '6', 'Guest Rooms (F6)', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('8', '7', 'Executive Suite (F7)', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('9', '8', 'Gym & Backup Hub', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('10', '9', 'Solar Roof', NULL, 'operational', '2026-02-17 19:37:45');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('11', '99', 'External / Playground', NULL, 'operational', '2026-02-17 19:37:45');


-- Structure for hardware_assets
DROP TABLE IF EXISTS `hardware_assets`;
CREATE TABLE `hardware_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `category` enum('Access Point','Switch','Workstation','Server','Printer','CCTV Camera','Other') DEFAULT 'Workstation',
  `location` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `floor_id` int(11) DEFAULT NULL,
  `condition_status` enum('working','needs_service','faulty') DEFAULT 'working',
  `condition_notes` text DEFAULT NULL,
  `warranty_expiry` date DEFAULT NULL,
  `maintenance_log` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  CONSTRAINT `hardware_assets_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `hardware_assets` (`id`, `name`, `serial_number`, `category`, `location`, `department`, `floor_id`, `condition_status`, `condition_notes`, `warranty_expiry`, `maintenance_log`, `created_at`) VALUES ('1', 'Dell PowerEdge R740', 'SRV-001-HQ', 'Workstation', 'Rack 1', 'IT', '2', 'working', NULL, NULL, NULL, '2026-02-17 19:37:45');
INSERT INTO `hardware_assets` (`id`, `name`, `serial_number`, `category`, `location`, `department`, `floor_id`, `condition_status`, `condition_notes`, `warranty_expiry`, `maintenance_log`, `created_at`) VALUES ('2', 'Reception WS-01', 'DT-992-REC', 'Workstation', 'Front Desk', 'Front Office', '2', 'working', NULL, NULL, NULL, '2026-02-17 19:37:45');
INSERT INTO `hardware_assets` (`id`, `name`, `serial_number`, `category`, `location`, `department`, `floor_id`, `condition_status`, `condition_notes`, `warranty_expiry`, `maintenance_log`, `created_at`) VALUES ('3', 'Unifi Switch Pro 48', 'SW-L2-02', 'Workstation', 'IDF Cabinet', 'IT', '2', 'needs_service', NULL, NULL, NULL, '2026-02-17 19:37:45');


-- Structure for ict_leave_requests
DROP TABLE IF EXISTS `ict_leave_requests`;
CREATE TABLE `ict_leave_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_by` int(11) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `ict_leave_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ict_leave_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for inventory_items
DROP TABLE IF EXISTS `inventory_items`;
CREATE TABLE `inventory_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `stock_level` int(11) DEFAULT 0,
  `reorder_threshold` int(11) DEFAULT 5,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `last_restocked` datetime DEFAULT NULL,
  `status` enum('in_stock','low_stock','out_of_stock') GENERATED ALWAYS AS (case when `stock_level` <= 0 then 'out_of_stock' when `stock_level` <= `reorder_threshold` then 'low_stock' else 'in_stock' end) VIRTUAL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for ip_assignments
DROP TABLE IF EXISTS `ip_assignments`;
CREATE TABLE `ip_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_id` int(11) DEFAULT NULL,
  `ip_address` varchar(50) NOT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `status` enum('static','dhcp_reserved','dynamic') DEFAULT 'static',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  CONSTRAINT `ip_assignments_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for issue_activity
DROP TABLE IF EXISTS `issue_activity`;
CREATE TABLE `issue_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `activity_type` enum('created','updated','status_changed','assigned','commented','attachment_added','time_logged','linked') NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_issue_id` (`issue_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `issue_activity_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_activity_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issue_activity` (`id`, `issue_id`, `user_id`, `activity_type`, `old_value`, `new_value`, `description`, `created_at`) VALUES ('1', '4', '1', 'attachment_added', NULL, NULL, 'User uploaded: photo_2026-01-28_23-56-31.jpg', '2026-02-17 20:40:40');


-- Structure for issue_attachments
DROP TABLE IF EXISTS `issue_attachments`;
CREATE TABLE `issue_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `uploaded_by` int(11) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_issue_id` (`issue_id`),
  CONSTRAINT `issue_attachments_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issue_attachments` (`id`, `issue_id`, `file_name`, `file_path`, `file_type`, `file_size`, `uploaded_by`, `uploaded_at`) VALUES ('1', '4', 'photo_2026-01-28_23-56-31.jpg', 'uploads/kb/kb_4_6994a818ecf26.jpg', 'image/jpeg', '126880', '1', '2026-02-17 20:40:40');


-- Structure for issue_comments
DROP TABLE IF EXISTS `issue_comments`;
CREATE TABLE `issue_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0 COMMENT '0=public, 1=internal note',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_issue_id` (`issue_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `issue_comments_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Structure for issue_relations
DROP TABLE IF EXISTS `issue_relations`;
CREATE TABLE `issue_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `related_issue_id` int(11) NOT NULL,
  `relation_type` enum('related','duplicate','blocks','blocked_by') DEFAULT 'related',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_relation` (`issue_id`,`related_issue_id`,`relation_type`),
  KEY `created_by` (`created_by`),
  KEY `idx_issue_id` (`issue_id`),
  KEY `idx_related_issue_id` (`related_issue_id`),
  CONSTRAINT `issue_relations_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_relations_ibfk_2` FOREIGN KEY (`related_issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_relations_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Structure for maintenance_tasks
DROP TABLE IF EXISTS `maintenance_tasks`;
CREATE TABLE `maintenance_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `priority` enum('low','medium','high','critical') DEFAULT 'medium',
  `proposed_solution` text DEFAULT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','in_progress','completed') DEFAULT 'pending',
  `assigned_to` varchar(100) DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT 0,
  `frequency` enum('daily','weekly','monthly','quarterly','yearly') DEFAULT NULL,
  `next_due_date` date DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `show_on_portal` tinyint(1) DEFAULT 0,
  `impact` enum('none','low','medium','high','outage') DEFAULT 'none',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for networks
DROP TABLE IF EXISTS `networks`;
CREATE TABLE `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `vlan_tag` int(11) DEFAULT NULL,
  `subnet` varchar(50) DEFAULT NULL,
  `gateway` varchar(50) DEFAULT NULL,
  `wifi_password` varchar(255) DEFAULT NULL,
  `is_wifi_hotspot` tinyint(1) DEFAULT 0,
  `hotspot_location` varchar(100) DEFAULT NULL,
  `hotspot_ssid` varchar(100) DEFAULT NULL,
  `password_last_changed` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('1', 'Office LAN', '10', '192.168.10.0/24', '192.168.10.1', NULL, '0', NULL, NULL, NULL, 'Main administrative network', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('2', 'Guest WiFi', '20', '10.0.0.0/16', '10.0.0.1', '@Premiere-2024', '1', 'Main Reception', 'HotelGuest-Public', NULL, 'Public guest access network', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('3', 'Voice & CCTV', '30', '172.16.0.0/24', '172.16.0.1', NULL, '0', NULL, NULL, NULL, 'Critical infrastructure segment', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('4', 'Manager Office WiFi', '15', '192.168.15.0/24', '192.168.15.1', 'Manager@2024Secure', '1', 'Manager Office - 3rd Floor', 'HotelStaff-Mgmt', NULL, 'Private WiFi for management team', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('5', 'Reception Office WiFi', '16', '192.168.16.0/24', '192.168.16.1', 'Reception#WiFi2024', '1', 'Reception Desk', 'HotelStaff-Reception', NULL, 'WiFi for reception staff', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('6', 'Kitchen Office WiFi', '17', '192.168.17.0/24', '192.168.17.1', 'Kitchen$Pass2024', '1', 'Kitchen Office', 'HotelStaff-Kitchen', NULL, 'WiFi for kitchen management', '2026-02-17 19:37:45');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('7', 'Housekeeping WiFi', '18', '192.168.18.0/24', '192.168.18.1', 'HouseKeep!2024', '1', 'Housekeeping Office - 2nd Floor', 'HotelStaff-HK', NULL, 'WiFi for housekeeping department', '2026-02-17 19:37:45');


-- Structure for notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `type` enum('info','warning','alert') DEFAULT 'info',
  `link_url` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for power_systems
DROP TABLE IF EXISTS `power_systems`;
CREATE TABLE `power_systems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `system_type` enum('Main Utility','UPS Cluster','Solar Array','Battery Storage') NOT NULL,
  `current_load_kw` decimal(10,2) DEFAULT 0.00,
  `battery_percentage` int(11) DEFAULT NULL,
  `status` enum('operational','maintenance','warning','fault') DEFAULT 'operational',
  `location` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('1', 'Main Grid Incomer', 'Main Utility', '450.50', NULL, 'operational', '1st Floor Main Server Room', NULL, '2026-02-17 19:37:45');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('2', 'Solar Bank Alpha', 'Solar Array', '85.00', '92', 'operational', 'Roof Top', NULL, '2026-02-17 19:37:45');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('3', 'Server Room UPS A', 'UPS Cluster', '12.80', '100', 'operational', '8th Floor Backup Room', NULL, '2026-02-17 19:37:45');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('4', 'Solar Storage Beta', 'Battery Storage', '0.00', '88', 'operational', '8th Floor Backup Room', NULL, '2026-02-17 19:37:45');


-- Structure for procurement_requests
DROP TABLE IF EXISTS `procurement_requests`;
CREATE TABLE `procurement_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('requested','approved','ordered','received','installed','cancelled') DEFAULT 'requested',
  `requester` varchar(100) DEFAULT NULL,
  `date_requested` date DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  CONSTRAINT `procurement_requests_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for quick_notes
DROP TABLE IF EXISTS `quick_notes`;
CREATE TABLE `quick_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `is_done` tinyint(1) DEFAULT 0,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `quick_notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for renewals
DROP TABLE IF EXISTS `renewals`;
CREATE TABLE `renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `contact_details` varchar(255) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `status` enum('active','expired','cancelled') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `billing_cycle` enum('monthly','yearly') DEFAULT 'yearly',
  `is_recurring` tinyint(1) DEFAULT 0,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  CONSTRAINT `renewals_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('1', 'Fiber Internet Line 1', '1', 'Account #88291', '1200.00', '2026-03-04', 'active', NULL, '2026-02-17 19:37:45', 'yearly', '0', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('2', 'Oracle Hospitality License', '2', 'Contract #OH-2024-X', '15000.00', '2026-05-17', 'active', NULL, '2026-02-17 19:37:45', 'yearly', '0', 'paid');


-- Structure for saved_filters
DROP TABLE IF EXISTS `saved_filters`;
CREATE TABLE `saved_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `filter_name` varchar(100) NOT NULL,
  `filter_criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filter_criteria`)),
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `saved_filters_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Structure for sop_documents
DROP TABLE IF EXISTS `sop_documents`;
CREATE TABLE `sop_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `version` varchar(20) DEFAULT '1.0',
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `author` varchar(100) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `visibility` enum('public','private') DEFAULT 'public',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for static_devices
DROP TABLE IF EXISTS `static_devices`;
CREATE TABLE `static_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(100) NOT NULL,
  `device_type` enum('Printer','POS','Scanner','IP Phone','Camera','Access Point','Other') DEFAULT 'Printer',
  `ip_address` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `network_id` int(11) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('online','offline','maintenance') DEFAULT 'online',
  `last_seen` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  CONSTRAINT `static_devices_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('1', 'Kitchen POS Terminal', 'POS', '192.168.10.50', 'Kitchen POS', '1', NULL, 'HP', 'ElitePOS G1', NULL, 'online', NULL, '2026-02-17 19:37:45', '2026-02-17 19:37:45');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('2', 'Reception Printer', 'Printer', '192.168.10.51', 'Front Desk Reception', '1', NULL, 'HP', 'LaserJet Pro M404dn', NULL, 'online', NULL, '2026-02-17 19:37:45', '2026-02-17 19:37:45');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('3', 'Bar POS', 'POS', '192.168.10.52', 'Bar Counter', '1', NULL, 'HP', 'ElitePOS G1', NULL, 'online', NULL, '2026-02-17 19:37:45', '2026-02-17 19:37:45');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('4', 'Accounting Printer', 'Printer', '192.168.10.53', 'Accounting Office', '1', NULL, 'Canon', 'imageCLASS MF445dw', NULL, 'online', NULL, '2026-02-17 19:37:45', '2026-02-17 19:37:45');


-- Structure for system_settings
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('1', 'contact_back_office_ext', '104', '2026-02-17 20:12:10', '2026-02-17 20:12:10');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('2', 'contact_duty_mobile', '0743 606 108', '2026-02-17 20:12:10', '2026-02-17 20:12:10');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('3', 'contact_duty_mobile_note', 'Calls only when unavailable in office', '2026-02-17 20:12:10', '2026-02-17 20:12:10');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('5', 'last_alarm_check', '1771697781', '2026-02-21 21:16:21', '2026-02-21 21:16:21');


-- Structure for time_logs
DROP TABLE IF EXISTS `time_logs`;
CREATE TABLE `time_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hours_spent` decimal(5,2) NOT NULL,
  `description` text DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_issue_id` (`issue_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_logged_at` (`logged_at`),
  CONSTRAINT `time_logs_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `troubleshooting_logs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `time_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Structure for troubleshooting_logs
DROP TABLE IF EXISTS `troubleshooting_logs`;
CREATE TABLE `troubleshooting_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requester_username` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `visibility` enum('public','internal') DEFAULT 'public',
  `priority` enum('low','medium','high','critical') DEFAULT 'medium',
  `system_affected` varchar(100) DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `root_cause` text DEFAULT NULL,
  `steps_taken` text DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `solution_image` varchar(255) DEFAULT NULL,
  `technician_name` varchar(100) DEFAULT NULL,
  `assigned_to` varchar(100) DEFAULT NULL,
  `incident_date` date DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_time_spent` decimal(5,2) DEFAULT 0.00 COMMENT 'Total hours spent on this issue',
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_assigned_to` (`assigned_to`),
  FULLTEXT KEY `idx_search` (`title`,`symptoms`,`resolution`),
  CONSTRAINT `troubleshooting_logs_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `troubleshooting_logs` (`id`, `requester_username`, `title`, `status`, `visibility`, `priority`, `system_affected`, `symptoms`, `root_cause`, `steps_taken`, `resolution`, `solution_image`, `technician_name`, `assigned_to`, `incident_date`, `due_date`, `vendor_id`, `created_at`, `total_time_spent`) VALUES ('2', 'admin', 'fff', 'open', 'public', 'medium', 'PublicAddress', 'REQUESTER: admin\nLOCATION: dd\n\nss', NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-17', NULL, NULL, '2026-02-17 20:15:16', '0.00');
INSERT INTO `troubleshooting_logs` (`id`, `requester_username`, `title`, `status`, `visibility`, `priority`, `system_affected`, `symptoms`, `root_cause`, `steps_taken`, `resolution`, `solution_image`, `technician_name`, `assigned_to`, `incident_date`, `due_date`, `vendor_id`, `created_at`, `total_time_spent`) VALUES ('3', 'admin', 'fff', 'open', 'public', 'medium', 'PublicAddress', 'REQUESTER: admin\nLOCATION: dd\n\nss', NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-17', NULL, NULL, '2026-02-17 20:20:19', '0.00');
INSERT INTO `troubleshooting_logs` (`id`, `requester_username`, `title`, `status`, `visibility`, `priority`, `system_affected`, `symptoms`, `root_cause`, `steps_taken`, `resolution`, `solution_image`, `technician_name`, `assigned_to`, `incident_date`, `due_date`, `vendor_id`, `created_at`, `total_time_spent`) VALUES ('4', 'admin', ']\\=', 'open', 'public', 'medium', 'WiFi', 'REQUESTER: admin\nLOCATION: \n\n,=', NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-17', NULL, NULL, '2026-02-17 20:40:40', '0.00');


-- Structure for users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `role` enum('admin','technician','viewer','staff') DEFAULT 'staff',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `department`, `role`, `status`, `created_at`) VALUES ('1', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@dallaspremiere.com', 'IT', 'admin', 'active', '2026-02-17 19:37:45');
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `department`, `role`, `status`, `created_at`) VALUES ('2', 'tech_support', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Technical Support', 'support@dallaspremiere.com', 'IT', 'staff', 'active', '2026-02-17 19:37:45');


-- Structure for vendors
DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `service_type` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `sla_notes` text DEFAULT NULL,
  `last_service_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('1', 'Telecom Plus', 'ISP & Telephony', 'Alice Johnson', '555-0101', 'alice@telecomplus.com', '4-hour onsite response time for critical outages.', '2023-12-15', '2026-02-17 19:37:45');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('2', 'HotelSys Global', 'PMS Support', 'Support Desk', '1-800-PMS-HELP', 'support@hotelsys.com', '24/7 Remote Support. Escalation to L2 after 1 hour.', '2024-01-10', '2026-02-17 19:37:45');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('3', 'CoolTech AC', 'Server Room Cooling', 'Bob Smith', '555-0202', 'bob@cooltech.com', 'Quarterly maintenance visits included.', '2024-02-01', '2026-02-17 19:37:45');

SET FOREIGN_KEY_CHECKS=1;
