-- Dallas Premiere ICT Management System Database Backup
-- Generated: 2026-02-21 15:40:35

SET FOREIGN_KEY_CHECKS=0;



-- Structure for audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('1', '1', 'UPDATE_STATUS', 'Ticket #1 status changed to closed', '2026-02-14 14:38:42');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('2', '1', 'UPDATE_STATUS', 'Ticket #2 status changed to closed', '2026-02-14 14:58:10');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('3', '3', 'User confirmed resolution for ticket #3', NULL, '2026-02-14 21:23:08');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('4', '4', 'CREATE_TASK', 'Created Task: Severt Boot', '2026-02-15 13:22:21');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('5', '4', 'CREATE_TICKET', 'Created Ticket: hjdjwhd', '2026-02-15 13:45:27');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('6', '4', 'DELETE', 'Deleted ticket #5 via bulk action', '2026-02-15 15:24:48');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('7', '4', 'DELETE', 'Deleted ticket #4 via bulk action', '2026-02-15 15:24:49');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('8', '4', 'User confirmed resolution for ticket #7', NULL, '2026-02-15 16:52:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('9', '4', 'CREATE_CREDENTIAL', 'Created credential for: Anydesk Password Attendance', '2026-02-17 16:41:53');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('10', '4', 'UPDATE_CREDENTIAL', 'Updated credential ID: 1', '2026-02-17 16:42:08');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('11', '4', 'REVEAL_PASSWORD', 'Revealed password for Credential ID: 1', '2026-02-21 13:01:02');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('12', '4', 'DELETE', 'Deleted ticket #9 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('13', '4', 'DELETE', 'Deleted ticket #10 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('14', '4', 'DELETE', 'Deleted ticket #11 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('15', '4', 'DELETE', 'Deleted ticket #12 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('16', '4', 'DELETE', 'Deleted ticket #13 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('17', '4', 'DELETE', 'Deleted ticket #14 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('18', '4', 'DELETE', 'Deleted ticket #15 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('19', '4', 'DELETE', 'Deleted ticket #16 via bulk action', '2026-02-21 14:29:46');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('20', '6', 'User confirmed resolution for ticket #17', NULL, '2026-02-21 14:38:31');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES ('21', '4', 'Generated full system backup: ICT_FULL_BACKUP_2026-02-21_15-40-27.zip', NULL, '2026-02-21 17:40:27');


-- Structure for backup_logs
DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_name` varchar(100) NOT NULL,
  `backup_type` varchar(50) DEFAULT NULL,
  `destination_disk` varchar(255) DEFAULT NULL,
  `last_verified` datetime DEFAULT NULL,
  `status` enum('safe','at_risk','failed') DEFAULT 'safe',
  `verified_by` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `backup_logs` (`id`, `asset_name`, `backup_type`, `destination_disk`, `last_verified`, `status`, `verified_by`, `notes`, `created_at`) VALUES ('1', 'cc', 'Database', 'ccc', NULL, 'safe', NULL, 'cc', '2026-02-15 13:21:02');


-- Structure for credential_vault
DROP TABLE IF EXISTS `credential_vault`;
CREATE TABLE `credential_vault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `system_name` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `encrypted_password` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `responsible_staff` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `credential_vault` (`id`, `user_id`, `system_name`, `username`, `encrypted_password`, `url`, `notes`, `responsible_staff`, `created_at`) VALUES ('1', '4', 'Anydesk Password Attendance', 'anydesk', 'dHB3ZlUvYS93cG5nWnRoZm01eGxCQT09Ojozt4fh33s3SIuDt78aDLpV', '', '', 'Reagan Harry', '2026-02-17 16:41:53');


-- Structure for data_links
DROP TABLE IF EXISTS `data_links`;
CREATE TABLE `data_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` int(11) DEFAULT NULL,
  `cabinet_name` varchar(50) NOT NULL,
  `total_u_space` int(11) DEFAULT 42,
  `used_u_space` int(11) DEFAULT 0,
  `switch_count` int(11) DEFAULT 0,
  `connectivity_type` enum('Fiber','Ethernet','Wireless Link') DEFAULT 'Fiber',
  `status` enum('online','degraded','offline') DEFAULT 'online',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  CONSTRAINT `data_links_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for external_links
DROP TABLE IF EXISTS `external_links`;
CREATE TABLE `external_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `category` enum('Network','Security','Vendor','Other') DEFAULT 'Other',
  `icon` varchar(50) DEFAULT 'link',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `external_links` (`id`, `name`, `url`, `category`, `icon`, `is_active`, `created_at`) VALUES ('1', 'Unifi Controller', 'http://127.0.0.1:8080/manage/default/dashboard', 'Network', 'wifi', '1', '2026-02-16 11:45:51');
INSERT INTO `external_links` (`id`, `name`, `url`, `category`, `icon`, `is_active`, `created_at`) VALUES ('2', '3cx IP PHONE Portal', 'http://192.168.3.3/#/people', 'Network', 'phone', '1', '2026-02-16 11:45:51');
INSERT INTO `external_links` (`id`, `name`, `url`, `category`, `icon`, `is_active`, `created_at`) VALUES ('9', 'Attendance Mangement Sytem', 'http://192.168.2.155/attendance', 'Network', 'link', '1', '2026-02-16 17:05:07');
INSERT INTO `external_links` (`id`, `name`, `url`, `category`, `icon`, `is_active`, `created_at`) VALUES ('10', 'Symphony -Reports ,POS Users', 'https://ors-idm.mte5.oraclerestaurants.com/oidc-ui/', 'Vendor', 'link', '1', '2026-02-16 17:29:02');
INSERT INTO `external_links` (`id`, `name`, `url`, `category`, `icon`, `is_active`, `created_at`) VALUES ('11', 'PMS Oracle ( Front Office)', 'https://idcs-773a3b1be5f3437c92d5634571b5d9d3.identity.oraclecloud.com/ui/v1/signin', 'Vendor', 'link', '1', '2026-02-16 17:30:04');


-- Structure for external_systems
DROP TABLE IF EXISTS `external_systems`;
CREATE TABLE `external_systems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `external_systems` (`id`, `name`, `url`, `notes`, `owner`, `created_at`) VALUES ('1', 'UNIFI Controler', 'http://127.0.0.1:8080/manage/default/dashboard', 'Access Point Control Panel', 'Patrick Mwangi', '2026-02-15 15:41:59');


-- Structure for floor_pins
DROP TABLE IF EXISTS `floor_pins`;
CREATE TABLE `floor_pins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` int(11) DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `data_link_id` int(11) DEFAULT NULL,
  `pos_x` int(11) DEFAULT NULL,
  `pos_y` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  KEY `asset_id` (`asset_id`),
  KEY `data_link_id` (`data_link_id`),
  CONSTRAINT `floor_pins_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `floor_pins_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `hardware_assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `floor_pins_ibfk_3` FOREIGN KEY (`data_link_id`) REFERENCES `data_links` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for floors
DROP TABLE IF EXISTS `floors`;
CREATE TABLE `floors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_number` int(11) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `map_image_path` varchar(255) DEFAULT NULL,
  `status` enum('operational','issue','offline') DEFAULT 'operational',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `floor_number` (`floor_number`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('1', '0', 'Basement', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('2', '1', 'Main Server & Lobby', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('3', '2', 'Conference Center', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('4', '3', 'Guest Rooms (F3)', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('5', '4', 'Guest Rooms (F4)', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('6', '5', 'Guest Rooms (F5)', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('7', '6', 'Guest Rooms (F6)', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('8', '7', 'Executive Suite (F7)', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('9', '8', 'Gym & Backup Hub', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('10', '9', 'Solar Roof', NULL, 'operational', '2026-02-14 13:02:22');
INSERT INTO `floors` (`id`, `floor_number`, `label`, `map_image_path`, `status`, `created_at`) VALUES ('11', '99', 'External / Playground', NULL, 'operational', '2026-02-14 13:02:22');


-- Structure for hardware_assets
DROP TABLE IF EXISTS `hardware_assets`;
CREATE TABLE `hardware_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `category` enum('Access Point','Switch','Workstation','Server','Printer','CCTV Camera','Other') DEFAULT 'Workstation',
  `location` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `floor_id` int(11) DEFAULT NULL,
  `condition_status` enum('working','needs_service','faulty') DEFAULT 'working',
  `condition_notes` text DEFAULT NULL,
  `warranty_expiry` date DEFAULT NULL,
  `maintenance_log` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `floor_id` (`floor_id`),
  KEY `idx_warranty` (`warranty_expiry`),
  KEY `idx_condition` (`condition_status`),
  CONSTRAINT `hardware_assets_ibfk_1` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for ict_leave_requests
DROP TABLE IF EXISTS `ict_leave_requests`;
CREATE TABLE `ict_leave_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_by` int(11) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `ict_leave_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ict_leave_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for inventory_items
DROP TABLE IF EXISTS `inventory_items`;
CREATE TABLE `inventory_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `stock_level` int(11) DEFAULT 0,
  `reorder_threshold` int(11) DEFAULT 5,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `last_restocked` datetime DEFAULT NULL,
  `status` enum('in_stock','low_stock','out_of_stock') GENERATED ALWAYS AS (case when `stock_level` <= 0 then 'out_of_stock' when `stock_level` <= `reorder_threshold` then 'low_stock' else 'in_stock' end) VIRTUAL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_stock` (`stock_level`,`reorder_threshold`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for ip_assignments
DROP TABLE IF EXISTS `ip_assignments`;
CREATE TABLE `ip_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_id` int(11) DEFAULT NULL,
  `ip_address` varchar(50) NOT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `status` enum('static','dhcp_reserved','dynamic') DEFAULT 'static',
  `connectivity_status` enum('online','offline','unknown') DEFAULT 'unknown',
  `last_seen` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  KEY `idx_ip_status` (`ip_address`,`status`),
  CONSTRAINT `ip_assignments_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ip_assignments` (`id`, `network_id`, `ip_address`, `device_name`, `mac_address`, `status`, `connectivity_status`, `last_seen`, `notes`) VALUES ('1', '8', '172.16.1.29', 'KTN PRN', '', 'static', 'online', '2026-02-20 09:00:05', 'kitchen Printer');
INSERT INTO `ip_assignments` (`id`, `network_id`, `ip_address`, `device_name`, `mac_address`, `status`, `connectivity_status`, `last_seen`, `notes`) VALUES ('2', '8', '172.16.1.25', 'BARPRN ', '', 'static', 'online', '2026-02-21 12:35:07', 'Bar ');
INSERT INTO `ip_assignments` (`id`, `network_id`, `ip_address`, `device_name`, `mac_address`, `status`, `connectivity_status`, `last_seen`, `notes`) VALUES ('3', '8', '172.16.1.32', 'COFFEE & BAR PRN', '', 'static', 'online', '2026-02-21 12:48:56', 'Close to cashier');
INSERT INTO `ip_assignments` (`id`, `network_id`, `ip_address`, `device_name`, `mac_address`, `status`, `connectivity_status`, `last_seen`, `notes`) VALUES ('4', '8', '172.16.1.26', 'Cashier Printer', '00-61-9A-67-4E-48', 'static', 'online', '2026-02-20 09:00:04', 'Cashier for bill printing');


-- Structure for issue_attachments
DROP TABLE IF EXISTS `issue_attachments`;
CREATE TABLE `issue_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for maintenance_tasks
DROP TABLE IF EXISTS `maintenance_tasks`;
CREATE TABLE `maintenance_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `priority` enum('low','medium','high','critical') DEFAULT 'medium',
  `proposed_solution` text DEFAULT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','in_progress','completed') DEFAULT 'pending',
  `assigned_to` varchar(100) DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT 0,
  `frequency` enum('daily','weekly','monthly','quarterly','yearly') DEFAULT NULL,
  `next_due_date` date DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `show_on_portal` tinyint(1) DEFAULT 0,
  `impact` enum('none','low','medium','high','outage') DEFAULT 'none',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_maintenance_due` (`next_due_date`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for networks
DROP TABLE IF EXISTS `networks`;
CREATE TABLE `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `vlan_tag` int(11) DEFAULT NULL,
  `subnet` varchar(50) DEFAULT NULL,
  `gateway` varchar(50) DEFAULT NULL,
  `wifi_password` varchar(255) DEFAULT NULL,
  `is_wifi_hotspot` tinyint(1) DEFAULT 0,
  `hotspot_location` varchar(100) DEFAULT NULL,
  `hotspot_ssid` varchar(100) DEFAULT NULL,
  `password_last_changed` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('2', 'Guest WiFi', '2', '192.168.100.1', '192.168.100.1', '@Premiere-2021', '1', 'Main Reception', 'Luxury Redefined ', '2026-02-14 15:12:24', 'Public guest access network', '2026-02-14 13:02:22');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('8', 'LAN', '1', '172.16.1.1', '172.16.1.1', '', '0', NULL, '', NULL, NULL, '2026-02-14 16:16:34');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('9', 'CCTV ', '3', '192.168.2.1', '192.168.3.1', '', '0', NULL, '', NULL, '', '2026-02-16 17:44:15');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('10', 'IP PHONE', '4', '255.255.255.0', '192.168.3.3', '', '0', NULL, '', NULL, '', '2026-02-21 12:17:31');
INSERT INTO `networks` (`id`, `name`, `vlan_tag`, `subnet`, `gateway`, `wifi_password`, `is_wifi_hotspot`, `hotspot_location`, `hotspot_ssid`, `password_last_changed`, `notes`, `created_at`) VALUES ('11', 'Ext NET', '4', '255.255.255.0', '192.168.2.1', '', '0', NULL, '', NULL, NULL, '2026-02-21 12:25:05');


-- Structure for notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `type` enum('info','warning','alert') DEFAULT 'info',
  `link_url` varchar(255) DEFAULT NULL,
  `target_role` varchar(50) DEFAULT 'all',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_is_read_role` (`is_read`,`target_role`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `notifications` (`id`, `message`, `type`, `link_url`, `target_role`, `is_read`, `created_at`) VALUES ('1', 'Renewal due in 7 days: Internet Subscription', 'alert', '/ict/modules/renewals/index.php', 'all', '1', '2026-02-15 15:33:08');
INSERT INTO `notifications` (`id`, `message`, `type`, `link_url`, `target_role`, `is_read`, `created_at`) VALUES ('2', 'Renewal due in 7 days: DSTV Provider Services', 'alert', '/ict/modules/renewals/index.php', 'admin', '1', '2026-02-21 12:05:02');
INSERT INTO `notifications` (`id`, `message`, `type`, `link_url`, `target_role`, `is_read`, `created_at`) VALUES ('3', 'Renewal due in 7 days: DSTV Provider Services', 'alert', '/ict/modules/renewals/index.php', 'admin', '1', '2026-02-21 13:11:35');
INSERT INTO `notifications` (`id`, `message`, `type`, `link_url`, `target_role`, `is_read`, `created_at`) VALUES ('4', 'New ticket submitted: eeee (medium)', 'info', '/ict/modules/knowledgebase/view.php?id=8', 'admin', '1', '2026-02-21 13:14:50');
INSERT INTO `notifications` (`id`, `message`, `type`, `link_url`, `target_role`, `is_read`, `created_at`) VALUES ('5', 'Renewal due in 7 days: DSTV Provider Services', 'alert', '/ict/modules/renewals/index.php', 'admin', '0', '2026-02-21 17:40:17');


-- Structure for portal_feedback
DROP TABLE IF EXISTS `portal_feedback`;
CREATE TABLE `portal_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `rating` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `portal_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for power_systems
DROP TABLE IF EXISTS `power_systems`;
CREATE TABLE `power_systems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `system_type` enum('Main Utility','UPS Cluster','Solar Array','Battery Storage') NOT NULL,
  `current_load_kw` decimal(10,2) DEFAULT 0.00,
  `battery_percentage` int(11) DEFAULT NULL,
  `status` enum('operational','maintenance','warning','fault') DEFAULT 'operational',
  `location` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('1', 'Main Grid Incomer', 'Main Utility', '450.50', NULL, 'operational', '1st Floor Main Server Room', NULL, '2026-02-14 13:02:22');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('2', 'Solar Bank Alpha', 'Solar Array', '85.00', '92', 'operational', 'Roof Top', NULL, '2026-02-14 13:02:22');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('3', 'Server Room UPS A', 'UPS Cluster', '12.80', '100', 'operational', '8th Floor Backup Room', NULL, '2026-02-14 13:02:22');
INSERT INTO `power_systems` (`id`, `name`, `system_type`, `current_load_kw`, `battery_percentage`, `status`, `location`, `notes`, `last_updated`) VALUES ('4', 'Solar Storage Beta', 'Battery Storage', '0.00', '88', 'operational', '8th Floor Backup Room', NULL, '2026-02-14 13:02:22');


-- Structure for procurement_requests
DROP TABLE IF EXISTS `procurement_requests`;
CREATE TABLE `procurement_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `status` enum('requested','approved','ordered','received','installed','cancelled') DEFAULT 'requested',
  `requester` varchar(100) DEFAULT NULL,
  `date_requested` date DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  CONSTRAINT `procurement_requests_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Structure for quick_notes
DROP TABLE IF EXISTS `quick_notes`;
CREATE TABLE `quick_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `is_done` tinyint(1) DEFAULT 0,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `quick_notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quick_notes` (`id`, `user_id`, `content`, `is_done`, `priority`, `created_at`, `updated_at`) VALUES ('3', '4', 'Lift Hall Direction Poster ', '1', 'medium', '2026-02-18 15:23:11', '2026-02-20 08:25:15');
INSERT INTO `quick_notes` (`id`, `user_id`, `content`, `is_done`, `priority`, `created_at`, `updated_at`) VALUES ('4', '4', 'Quotation Follow Up', '0', 'medium', '2026-02-18 15:23:33', '2026-02-21 13:17:32');
INSERT INTO `quick_notes` (`id`, `user_id`, `content`, `is_done`, `priority`, `created_at`, `updated_at`) VALUES ('5', '4', 'meal cards lamination ', '1', 'medium', '2026-02-20 08:25:37', '2026-02-21 12:31:45');
INSERT INTO `quick_notes` (`id`, `user_id`, `content`, `is_done`, `priority`, `created_at`, `updated_at`) VALUES ('6', '4', '424 door lock ', '0', 'medium', '2026-02-20 08:26:08', '2026-02-21 17:32:28');
INSERT INTO `quick_notes` (`id`, `user_id`, `content`, `is_done`, `priority`, `created_at`, `updated_at`) VALUES ('7', '4', 'check all the ip address of all printer and work stations', '1', 'medium', '2026-02-20 08:42:31', '2026-02-21 12:31:50');


-- Structure for renewals
DROP TABLE IF EXISTS `renewals`;
CREATE TABLE `renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `contact_details` varchar(255) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `status` enum('active','expired','cancelled') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `billing_cycle` enum('monthly','yearly') DEFAULT 'yearly',
  `is_recurring` tinyint(1) DEFAULT 0,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `idx_renewal_status` (`renewal_date`,`status`),
  CONSTRAINT `renewals_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('3', 'Internet Subscription', '4', '', '20000.00', '2027-02-16', 'active', '', '2026-02-15 15:31:23', 'monthly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('4', 'Hosting services', '5', '', '7999.00', '2026-08-27', 'active', '', '2026-02-17 10:15:58', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('5', '3cx 4SC IP Phone', '11', '0703737637', '37900.00', '2026-12-11', 'active', '', '2026-02-17 10:22:50', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('6', 'Google Workspace', '7', '0743695200', '121892.00', '2026-04-16', 'active', '', '2026-02-17 10:25:49', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('7', 'ELaah Quotations', '8', '0743695200', '278400.00', '2026-02-03', 'active', '6 months recurring', '2026-02-17 10:28:06', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('8', 'TRA Licensing', '6', '0701444777', '44000.00', '2027-01-21', 'active', '', '2026-02-17 10:30:58', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('9', 'DSTV Provider Services', '9', '', '37070.00', '2026-02-28', 'active', '', '2026-02-17 10:33:46', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('10', 'ODPC Licenses', '12', '', '16000.00', '2027-10-20', 'active', '', '2026-02-17 15:02:14', 'yearly', '0', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('11', 'Trading License', '13', '', '0.00', '2025-12-31', 'active', '', '2026-02-17 15:04:03', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('12', 'Tax Compliance Certificate', '14', '', '0.00', '2026-05-21', 'active', '', '2026-02-17 15:06:05', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('13', 'Food &amp; Hygiene Certificate', '15', '', '0.00', '2025-12-31', 'active', '', '2026-02-17 15:07:36', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('14', 'MCSK License', '16', '', '0.00', '2026-10-24', 'active', 'awaiting certificate', '2026-02-17 15:09:38', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('15', 'Liquor License', '17', '', '0.00', '2025-12-31', 'active', '', '2026-02-17 15:11:18', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('16', 'DOSH -General Safety Compliance', '18', '', '0.00', '2026-05-24', 'active', '', '2026-02-17 15:12:40', 'yearly', '1', 'paid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('17', 'Workplace Safety Certificate', '19', '', '0.00', '2025-12-18', 'active', '', '2026-02-17 15:13:42', 'yearly', '1', 'unpaid');
INSERT INTO `renewals` (`id`, `service_name`, `vendor_id`, `contact_details`, `amount_paid`, `renewal_date`, `status`, `notes`, `created_at`, `billing_cycle`, `is_recurring`, `payment_status`) VALUES ('18', 'Water Permit', '20', '', '0.00', '2029-03-20', 'active', 'Long Term Validity', '2026-02-17 15:14:46', 'yearly', '0', 'paid');


-- Structure for sop_documents
DROP TABLE IF EXISTS `sop_documents`;
CREATE TABLE `sop_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `version` varchar(20) DEFAULT '1.0',
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `author` varchar(100) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `visibility` enum('public','private') DEFAULT 'public',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sop_documents` (`id`, `title`, `category`, `content`, `version`, `last_updated`, `author`, `image_path`, `visibility`) VALUES ('1', 'Kitchen Printer Not Receiving Orders — Network Configuration Fix', 'KOT', '<h3><strong>Issue Summary</strong></h3><p>The kitchen printer was not receiving orders from the POS system. When orders were sent, the Kitchen Order Ticket (KOT) was instead printing on backup printers (bar and coffee shop POS printers).</p><p>This indicated a communication failure between the kitchen printer and the POS network.</p><p>The environment uses Oracle MICROS POS with printers configured to communicate over a VLAN.</p><h3><strong>Symptoms Observed</strong></h3><ul><li>Kitchen printer did not print incoming orders</li><li>Orders were redirected to backup printers</li><li>No visible hardware faults on the printer</li></ul><h3><strong>Root Cause</strong></h3><p>A printer self-test revealed that the kitchen printer was configured with an incorrect IP address on a different subnet:</p><pre class=\"ql-syntax\" spellcheck=\"false\">Incorrect network: 192.168.3.x\r\nRequired VLAN network: 172.16.1.x\r\n</pre><p>Because the printer was outside the POS VLAN, it could not communicate with POS workstations or the order routing system.</p><h3><strong>Troubleshooting &amp; Resolution Step</strong>s</h3><h4>1. Verify Printer Network Configuration</h4><ul><li>Performed a printer self-test</li><li>Confirmed printer IP was outside the required VLAN</li></ul><h4>2. Reconfigure Printer Network Settings</h4><ul><li>Disconnected printer from network</li><li>Connected printer to laptop via USB</li><li>Used the XPrinter Tool to access printer configuration</li></ul><h4>3. Confirm POS Printer Settings</h4><ul><li>Logged into Oracle Enterprise Management Console</li><li>Navigated to hardware/printer configuration</li><li>Verified the assigned kitchen printer IP</li></ul><h4>4. Assign Correct Network Address</h4><ul><li>Updated printer IP to:</li></ul><pre class=\"ql-syntax\" spellcheck=\"false\">172.16.1.29\r\n</pre><ul><li>Saved and applied configuration</li></ul><h4>5. Network Verification</h4><ul><li>Pinged printer IP to confirm communication</li><li>Verified stable network response</li></ul><h4>6. Functional Test</h4><ul><li>Sent a test kitchen order</li><li>Confirmed KOT printed correctly on the kitchen printer</li></ul><h3><strong>Outcome</strong></h3><ul><li>Kitchen printer restored to correct VLAN communication</li><li>Orders routed correctly to intended printer</li><li>Backup printer fallback eliminated</li></ul><h3>Key Takeaway</h3><p>POS printers must reside on the same VLAN/subnet as workstations for order routing to function correctly. Misconfigured IP addresses can cause silent routing failures.</p>', '1.6', '2026-02-17 10:11:40', 'Harry Reagan', NULL, 'public');
INSERT INTO `sop_documents` (`id`, `title`, `category`, `content`, `version`, `last_updated`, `author`, `image_path`, `visibility`) VALUES ('3', 'How to Add a New Article in Material Control (MC)', 'Material Control(MC)', '<h2>Overview</h2><p>This guide explains the process of creating a new article in the Material Control (MC) system, assigning it correctly within the inventory hierarchy, and linking it to production/POS when required.</p><h2>Part 1 — Create a New Article in Material Control</h2><h3>Step 1 — Open Article Creation</h3><ol><li>Log into the <strong>Material Control (MC)</strong> system.</li><li>Navigate to the top ribbon menu.</li><li>Select:</li><li><strong>Ribbon → Master Data → Control Repository</strong></li></ol><h3>Step 2 — Add the Article</h3><ol><li>Click <strong>Procure → Add</strong>.</li><li>Enter the required article details:</li></ol><ul><li class=\"ql-indent-1\">Article name</li><li class=\"ql-indent-1\">Category/type</li><li class=\"ql-indent-1\">Storage/usage information</li></ul><ol><li>Ensure all required fields are completed.</li></ol><h3>Step 3 — Assign Inventory Hierarchy</h3><p>Every article must be placed within the inventory structure:</p><p>Inventory hierarchy structure:</p><pre class=\"ql-syntax\" spellcheck=\"false\">Over Group\r\n   ↓\r\nMajor Group\r\n   ↓\r\nItem Group\r\n   ↓\r\nArticle\r\n</pre><p>Assign the new article to the correct:</p><ul><li>Over group</li><li>Major group</li><li>Item group</li></ul><p>This ensures proper reporting, procurement tracking, and storage management.</p><h3>Step 4 — Assign Profit/Expense Base</h3><ol><li>Link the article to the appropriate <strong>profit or expense base</strong>.</li><li>Confirm the correct item group association.</li></ol><h3>Step 5 — Save the Article</h3><ol><li>Click <strong>Save</strong>.</li><li>Confirm the article is successfully created.</li></ol><h2>Part 2 — Link Article to Recipe (If Required)</h2><p>If the article is used in production or POS:</p><ol><li>Open the production or recipe module.</li><li>Search for the product by name.</li><li>Select the item.</li><li>Click <strong>Link Product</strong>.</li><li>Choose:</li><li><strong>Link as Recipe</strong></li><li>Click <strong>Create Recipe</strong>.</li><li>Save the recipe.</li><li>Select <strong>Save &amp; Next</strong> if linking multiple items.</li></ol><h2>Part 3 — Product Sync / Database Update</h2><p>After article creation:</p><ol><li>Run product synchronization (if applicable).</li><li>Confirm the article reflects correctly in POS/production systems.</li></ol><p>Status indicators:</p><ul><li><strong>U</strong> → Unlinked</li><li><strong>R</strong> → Linked</li></ul><p>Ensure the article status shows <strong>Linked</strong> where required.</p><h2>Notes</h2><ul><li>If an item/service does not exist in the system, it must be created through master data before use.</li><li>Proper hierarchy assignment prevents reporting and procurement errors.</li><li>Always verify synchronization after creation.</li></ul><p><br></p>', '1.0', '2026-02-17 14:19:29', 'Harry Reagan', NULL, 'private');
INSERT INTO `sop_documents` (`id`, `title`, `category`, `content`, `version`, `last_updated`, `author`, `image_path`, `visibility`) VALUES ('4', 'Oracle SUN Systems Financial Client', 'SUN System', '<h2>Installation Guide — Windows Workstation</h2><h3>Purpose</h3><p>This document provides step-by-step instructions for installing the Oracle SUN Systems Financial client on a Windows workstation and connecting it to the SUN Systems server.</p><h2>Prerequisites</h2><p>Before installation, confirm the following:</p><ul><li>You have <strong>administrator rights</strong> on the workstation</li><li>Access to the SUN Systems installation files</li><li>Server IP address is available</li><li><em>(example: 172.16.1.11 — replace with your environment)</em></li><li>Network connectivity to the server is verified</li><li>Backup of important workstation data is completed</li></ul><h2>Step 1 — Verify Server Connectivity</h2><ol><li>Confirm the SUN server IP address.</li><li>From the workstation:</li></ol><ul><li class=\"ql-indent-1\">Open Command Prompt</li><li class=\"ql-indent-1\">Ping the server IP</li></ul><pre class=\"ql-syntax\" spellcheck=\"false\">ping 172.16.1.11\r\n</pre><ol><li>Ensure replies are received before proceeding.</li></ol><h2>Step 2 — Prepare Installation Files</h2><ol><li>Copy the SUN Systems installation folder to the workstation</li><li><em>(example location: Drive D:\\ or shared network folder)</em>.</li><li>Confirm the correct version is available (e.g., v6 or v6.2 patch).</li></ol><h2>Step 3 — Install SUN Systems Client</h2><ol><li>Navigate to the installation folder.</li><li>Right-click <strong>setup.exe</strong> → select <strong>Run as Administrator</strong>.</li><li>Choose:</li><li><strong>Custom Installation</strong></li><li>When feature options appear:</li></ol><ul><li class=\"ql-indent-1\">Uncheck all components</li><li class=\"ql-indent-1\">Select only:</li></ul><ol><li>✔ Client SS (Client Component)</li><li>Proceed with installation.</li></ol><h2>Step 4 — Security Configuration</h2><ol><li>Launch SUN Systems Security / User Manager.</li><li>Enter administrator credentials.</li><li>Confirm the server connection:</li></ol><pre class=\"ql-syntax\" spellcheck=\"false\">Server IP: 172.16.1.11\r\n</pre><ol><li>Enable log visibility if prompted.</li><li>Finish configuration.</li></ol><h2>Step 5 — Apply Patch Update (if required)</h2><ol><li>Locate the patch installer (example: v6.2 patch).</li><li>Run as Administrator.</li><li>Follow prompts to update.</li><li>Wait for completion.</li></ol><h2>Step 6 — Install Vision/Q&amp;A Client</h2><ol><li>Navigate to the Vision/Q&amp;A client installer.</li><li>Run setup.</li><li>Install required components.</li><li>When prompted for server details:</li></ol><pre class=\"ql-syntax\" spellcheck=\"false\">Server Name: SUNSERVER\r\nPort: 8880\r\n</pre><ol><li>Complete installation.</li></ol><h2>Step 7 — First Launch &amp; Excel Integration</h2><ol><li>Open Microsoft Excel.</li><li>The Vision/Q&amp;A add-in should load automatically.</li><li>Click <strong>Logon</strong>.</li><li>If prompted to update:</li></ol><ul><li class=\"ql-indent-1\">Choose <strong>YES</strong> (unless instructed otherwise).</li></ul><ol><li>Minimize or close Excel if required.</li></ol><h2><br></h2>', '1.0', '2026-02-18 10:33:17', 'Harry Reagan', NULL, 'private');


-- Structure for static_devices
DROP TABLE IF EXISTS `static_devices`;
CREATE TABLE `static_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(100) NOT NULL,
  `device_type` enum('Printer','POS','Scanner','IP Phone','Camera','Access Point','Other') DEFAULT 'Printer',
  `ip_address` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `network_id` int(11) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('online','offline','maintenance') DEFAULT 'online',
  `last_seen` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  KEY `idx_ip_status` (`ip_address`,`status`),
  CONSTRAINT `static_devices_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('6', 'BAR Work Station 2', 'POS', '172.16.1.22', 'Bar', '8', NULL, 'XPRINTER', NULL, NULL, 'online', '2026-02-21 12:38:39', '2026-02-21 12:07:32', '2026-02-21 12:38:39');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('7', 'Cashier Work Station 1', 'POS', '172.16.1.21', '(Cashier position)Front Restaurant ', '8', NULL, 'Micros', NULL, NULL, 'online', '2026-02-21 12:38:12', '2026-02-21 12:09:50', '2026-02-21 12:38:12');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('10', 'Cashier Work Station 3', 'POS', '172.16.1.23', 'posting (Cashier position) Front Restaurant ', '8', NULL, NULL, NULL, 'For posting by waiters', 'online', '2026-02-21 12:38:40', '2026-02-21 12:13:41', '2026-02-21 12:38:40');
INSERT INTO `static_devices` (`id`, `device_name`, `device_type`, `ip_address`, `location`, `network_id`, `mac_address`, `manufacturer`, `model`, `notes`, `status`, `last_seen`, `created_at`, `updated_at`) VALUES ('11', 'Attendance Management System', 'Other', '192.168.2.155', 'Back Entrace', '11', NULL, 'American Mega Trends', NULL, NULL, 'online', '2026-02-21 12:48:54', '2026-02-21 12:22:34', '2026-02-21 12:54:50');


-- Structure for system_settings
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('1', 'contact_back_office_ext', '104', '2026-02-14 13:29:14', '2026-02-14 13:29:14');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('2', 'contact_duty_mobile', '0000000001', '2026-02-14 13:29:14', '2026-02-20 09:00:58');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('3', 'contact_duty_mobile_note', 'Calls only when unavailable in office', '2026-02-14 13:29:14', '2026-02-14 13:29:14');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('10', 'last_alarm_check', '1771684817', '2026-02-21 12:23:03', '2026-02-21 17:40:17');


-- Structure for troubleshooting_logs
DROP TABLE IF EXISTS `troubleshooting_logs`;
CREATE TABLE `troubleshooting_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requester_username` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `visibility` enum('public','internal') DEFAULT 'public',
  `priority` enum('low','medium','high','critical') DEFAULT 'medium',
  `system_affected` varchar(100) DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `root_cause` text DEFAULT NULL,
  `steps_taken` text DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `solution_image` varchar(255) DEFAULT NULL,
  `technician_name` varchar(100) DEFAULT NULL,
  `assigned_to` varchar(100) DEFAULT NULL,
  `incident_date` date DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  CONSTRAINT `troubleshooting_logs_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `troubleshooting_logs` (`id`, `requester_username`, `title`, `status`, `visibility`, `priority`, `system_affected`, `symptoms`, `root_cause`, `steps_taken`, `resolution`, `solution_image`, `technician_name`, `assigned_to`, `incident_date`, `due_date`, `vendor_id`, `created_at`) VALUES ('1', NULL, 'Unable To Access Finace Shared Folder', 'closed', 'public', 'high', 'Finance Department Computer', '<p>Staff Benedictor  Reported Unable to access finances only shared  folder</p>', '<p>Main Host -Finance Computer Change of IP4 address from static to dynamic</p>', '<ol><li>I confirmed whether finance computer (Christine\'s)   is  turned on on</li><li>Then i checked the IP address from (Command Prompt )cmd using the IPCONFIG query </li><li>Then I went to  control panel ---Ethernet ----adapter setting ---- properties ---ipv4 </li><li>i changed the Ip address form DHCP 172.16.1.76 to static </li><li>Subnet mask 255.255.255.0 Default gateway is 172.16.1.1</li><li>The final Step is I come now to the affected user (Bena comp) and network , key in \\\\172.16.1.76. the finance folder will be discovered</li><li>Map the folder as drive .</li></ol>', '<p>In a case the public or private folders that are sharable are not discovered in the network , Check the Ip address of the host device  , usually the ICT Computer of Finance Computer and change their IP4  adress from DHCP to Static.</p>', NULL, 'tech_support', 'admin', '2026-02-09', NULL, NULL, '2026-02-14 13:02:22');
INSERT INTO `troubleshooting_logs` (`id`, `requester_username`, `title`, `status`, `visibility`, `priority`, `system_affected`, `symptoms`, `root_cause`, `steps_taken`, `resolution`, `solution_image`, `technician_name`, `assigned_to`, `incident_date`, `due_date`, `vendor_id`, `created_at`) VALUES ('2', 'Phelix', 'F N B  DepartmentComputer Not turning on', 'closed', 'internal', 'high', 'F n B Computer', '<p>Staff Seth reported there main Computer , F n B office  is not turning On</p>', '<p>Accidental switching off of the up that act as the main current supplier to the computer </p>', '<ol><li>I pressed on the power button for both the CPU and The screen to a certain that it indeed not turning on .</li><li>I checked if the power is on on the lighting system --- bulb (Ok)</li><li>I checked if the main source socket is in , this in volved the extension sockets ---(OK)</li><li>I checked whether the UPS is on .( Confirmed it was off)</li><li>Turned it on and turned the CPU and screen on </li></ol><p><br></p>', '<p>Check IF the power cords , from the main source to UPS to Computer Frame is well connected and all switched on.</p>', NULL, NULL, 'tech_support', '2026-02-14', NULL, NULL, '2026-02-14 13:28:04');


-- Structure for users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `duty_number` varchar(20) DEFAULT NULL,
  `role` enum('admin','technician','viewer','staff') DEFAULT 'staff',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `department`, `extension`, `duty_number`, `role`, `status`, `created_at`) VALUES ('4', 'admin', '$2y$10$J6sM3l/9YX4toPJ6wsJ3wecqoR1My6Q6FjFsF6fid2xxtVm5Ytobe', 'System Administrator', 'ict@dallas.ke', 'IT', '', '', 'admin', 'active', '2026-02-15 08:48:55');
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `department`, `extension`, `duty_number`, `role`, `status`, `created_at`) VALUES ('5', 'test', '$2y$10$VteLzxyC4P3eDnlZb1/0AO.g8Bk4SVwPd82aFNJ1dw36GUr4KHQB2', 'test', '', '', '', '', 'staff', 'active', '2026-02-21 13:13:50');
INSERT INTO `users` (`id`, `username`, `password_hash`, `full_name`, `email`, `department`, `extension`, `duty_number`, `role`, `status`, `created_at`) VALUES ('6', 'test2', '$2y$10$mdvvURthfj027QAYY/RLSeCQTlAB8sWYBT6cIxxuR9sh43zk/2W16', 'test2', '', 'IT Department', '', '', 'technician', 'active', '2026-02-21 13:23:32');


-- Structure for vendors
DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `service_type` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `sla_notes` text DEFAULT NULL,
  `last_service_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('4', 'Safaricom', 'Internet Service Provider', '', '', '', '', '2026-02-08', '2026-02-15 15:30:44');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('5', 'Hosting.com', 'Hosting Services', '', '', 'support@hosting.com', '', '2025-08-27', '2026-02-17 09:54:48');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('6', 'Tourism Regulatory Authority Licence (TRA)', 'Tourism Services', '', '', '', '', '2026-01-17', '2026-02-17 09:56:06');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('7', 'CHIKA', 'Google WorKSpace- dallas.ke gmails', '0743695200', '07436952200', '', 'Gmail  host', '2025-04-23', '2026-02-17 09:56:36');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('8', 'CHIKA', 'ELLAH', '0743695200', '', '', '', NULL, '2026-02-17 10:05:13');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('9', 'Multichoice', 'TV service   provider', '', '', '', '', NULL, '2026-02-17 10:06:07');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('10', 'Oracle Sytems By PesaPal', 'PMS, POS .MC', '', '', '', '', NULL, '2026-02-17 10:06:47');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('11', 'ITABLE Tech Limited', '3CX IP Phone', '', '0729446207', 'info@itabletech.co.ke', '', '2025-12-11', '2026-02-17 10:20:51');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('12', 'Office of the Data Protection Commissioner', 'ODPC License /Personal Data Protection', '', '', '', '', NULL, '2026-02-17 14:35:54');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('13', 'Kenya Trade Portal', 'Trading License', '', '', '', '', NULL, '2026-02-17 14:39:41');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('14', 'Kenya Revenue Authority(KRA)', 'Tax Compliance Certificate', '', '', '', '', NULL, '2026-02-17 14:40:27');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('15', 'Ministry Of Health', 'Food and Hygiene Certificate', '', '', '', '', NULL, '2026-02-17 14:41:51');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('16', 'Music Copyright Society Of Kenya (MCSK)', 'MCSK Certificate', '', '', '', '', NULL, '2026-02-17 14:43:24');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('17', 'Kisii County', 'Liquor Licenses', '', '', '', '', NULL, '2026-02-17 14:46:17');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('18', 'Directorate of Occupational Saferty and health services', 'DOSH-General safety Compliance', '', '', '', '', NULL, '2026-02-17 14:49:06');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('19', 'Ministry Of Labour and Social Protection', 'Work Place Safety Certificate', '', '', '', '', NULL, '2026-02-17 14:50:48');
INSERT INTO `vendors` (`id`, `name`, `service_type`, `contact_person`, `phone`, `email`, `sla_notes`, `last_service_date`, `created_at`) VALUES ('20', 'Water Resources Authority', 'Water Permit', '', '', '', '', NULL, '2026-02-17 14:52:17');

SET FOREIGN_KEY_CHECKS=1;
